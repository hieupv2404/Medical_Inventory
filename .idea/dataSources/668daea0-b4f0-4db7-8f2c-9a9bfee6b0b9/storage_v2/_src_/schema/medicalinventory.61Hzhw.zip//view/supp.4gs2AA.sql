create definer = root@localhost view supp as
select `s`.`supplier_id`      AS `supplier_id`,
       `s`.`email`            AS `email`,
       `s`.`number_phone`     AS `number_phone`,
       `s`.`supplier_address` AS `supplier_address`,
       `s`.`supplier_name`    AS `supplier_name`
from `medicalinventory`.`supplier` `s`
         join `medicalinventory`.`invoice` `i`
where ((`i`.`supplier_id` = `s`.`supplier_id`) and (`i`.`type` = 1) and (`i`.`active_flag` = 1));

